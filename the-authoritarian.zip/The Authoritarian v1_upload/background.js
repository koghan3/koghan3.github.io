// ==========================================
// The Authoritarian - Background Service Worker
// ==========================================

const DEFAULT_SETTINGS = {
  dailyAllowanceMinutes:    30,
  maxPerVisitMinutes:       5,
  visitCooldownMinutes:     5,
  pomodoroWorkMinutes:      25,
  pomodoroBreakMinutes:     5,
  longBreakMinutes:         20,
  sessionsBeforeLongBreak:  4,
  focusCheckCount:          1,     // number of check-ins evenly distributed across the session
  focusCheckTimeoutAction:  'distracted', // 'distracted' = restart session | 'focused' = continue silently
  breakBonusMinutes:        10,    // extra minutes of break available per completed session
  extendBreakByMinutes:     1,     // how many minutes each "+min" press adds
  thresholdMinutes:         30,
  autoblockEnabled:         false,
  autoblockMinutes:         60,
  lockMinWaitMinutes:       3,
  lockMinWords:             50
};

// --------------- State helpers ---------------

async function getStorage(keys) {
  return chrome.storage.local.get(keys);
}

async function setStorage(data) {
  return chrome.storage.local.set(data);
}

function getDomainFromUrl(url) {
  try {
    const u = new URL(url);
    if (['chrome:', 'chrome-extension:', 'about:', 'edge:', 'moz-extension:'].includes(u.protocol)) return null;
    return u.hostname;
  } catch {
    return null;
  }
}

function getTodayKey() {
  return new Date().toISOString().slice(0, 10);
}

// Normalise a raw hostname to match blacklist/whitelist keys.
// Strips leading "www." so "www.reddit.com" → "reddit.com".
function normaliseHostname(hostname) {
  return hostname.replace(/^www\./, '');
}

// Look up a hostname in the blacklist, tolerating www-prefixed hostnames.
// Returns the entry object or null/undefined.
function blEntry(blacklist, hostname) {
  return blacklist[hostname] || blacklist[normaliseHostname(hostname)] || null;
}

// Same for whitelist (returns truthy/falsy).
function wlEntry(whitelist, hostname) {
  return whitelist[hostname] || whitelist[normaliseHostname(hostname)];
}

// --------------- UI helpers ---------------

function setBadge(text, color) {
  try {
    chrome.action.setBadgeText({ text });
    if (color) chrome.action.setBadgeBackgroundColor({ color });
  } catch {}
}

// Format milliseconds into a compact badge string: e.g. "24:07" or "4:30"
function fmtBadge(ms) {
  if (ms <= 0) return '0:00';
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}

// Update badge to show live countdown for active pomodoro sessions
function updateBadgeTimer(pomodoro) {
  if (!pomodoro || !pomodoro.active || !pomodoro.endTime) {
    // Not in a session — clear badge
    setBadge('', null);
    return;
  }
  const remaining = pomodoro.endTime - Date.now();
  const text = fmtBadge(remaining);
  const color = pomodoro.mode === 'work' ? '#7a1010' : '#4a6230';
  setBadge(text, color);
}

// sendNotification: always tries a system notification.
// For session transitions, also pass endTime + mode to open a visible dispatch tab.
async function sendNotification(title, message, endTime = null, mode = 'work') {
  // Always attempt system notification
  try {
    const level = await chrome.notifications.getPermissionLevel();
    if (level === 'granted') {
      await chrome.notifications.create(`auth_${Date.now()}`, {
        type:    'basic',
        iconUrl: chrome.runtime.getURL('icons/icon128.png'),
        title,
        message
      });
    }
  } catch (e) {
    console.error('Notification error:', e);
  }

  // For session events (endTime provided) always open a visible dispatch tab with timer
  // and bring the Chrome window to the foreground to grab attention
  if (endTime !== null) {
    const url = chrome.runtime.getURL('notify.html')
      + `?title=${encodeURIComponent(title)}`
      + `&msg=${encodeURIComponent(message)}`
      + `&endTime=${endTime}`
      + `&mode=${encodeURIComponent(mode)}`;
    try {
      const tab = await chrome.tabs.create({ url, active: true });
      chrome.windows.update(tab.windowId, { focused: true, drawAttention: true });
    } catch {}
  }
}

// --------------- Settings Lock helpers ---------------

async function isLocked() {
  const { settingsLocked } = await getStorage('settingsLocked');
  return !!settingsLocked;
}

// --------------- Initialisation ---------------

chrome.runtime.onInstalled.addListener(async (details) => {
  const { settings } = await getStorage('settings');
  if (!settings) {
    await setStorage({ settings: DEFAULT_SETTINGS });
  } else {
    const merged = Object.assign({}, DEFAULT_SETTINGS, settings);
    await setStorage({ settings: merged });
  }

  await setStorage({
    pomodoro: { active: false, mode: 'idle', endTime: null, sessionCount: 0 }
  });

  chrome.runtime.setUninstallURL(chrome.runtime.getURL('plea.html'));

  if (details.reason === 'install') {
    await setStorage({
      blacklist:      {},
      whitelist:      {},
      tracking:       {},
      prompted:       {},
      cooldowns:      {},
      settingsLocked: false,
      unlockRequest:  null,
      pomodoroStats:  { totalSessions: 0, totalFocusMinutes: 0, totalBreakMinutes: 0, history: [] }
    });
  } else {
    // Ensure pomodoroStats exists on upgrade
    const { pomodoroStats } = await getStorage('pomodoroStats');
    if (!pomodoroStats) {
      await setStorage({ pomodoroStats: { totalSessions: 0, totalFocusMinutes: 0, totalBreakMinutes: 0, history: [] } });
    }
  }
});

// Note: setUninstallURL only accepts http/https — plea.html is accessible via the popup instead.

// Re-apply declarative rules on service worker restart
updateDeclarativeRules();

// Periodic tracking tick every 15 seconds
chrome.alarms.create('trackingTick', { periodInMinutes: 0.25 });

chrome.alarms.onAlarm.addListener(async (alarm) => {
  const run = async (fn) => { try { await fn(); } catch (e) { console.error(`Alarm handler error [${alarm.name}]:`, e); } };

  if (alarm.name === 'trackingTick')        await run(trackActiveTab);
  if (alarm.name === 'pomodoroEnd')         await run(handlePomodoroEnd);
  if (alarm.name === 'focusCheckReminder')  await run(handleFocusCheckReminder);
  if (alarm.name === 'focusCheckTimeout')   await run(handleFocusCheckTimeout);
  if (alarm.name.startsWith('focusCheck_') && alarm.name !== 'focusCheckReminder') {
    await run(handleFocusCheck);
  }
  if (alarm.name.startsWith('cooldown_')) {
    await run(async () => {
      const domain = decodeURIComponent(alarm.name.slice('cooldown_'.length));
      const { cooldowns = {} } = await getStorage('cooldowns');
      delete cooldowns[domain];
      await setStorage({ cooldowns });
    });
  }
});

// --------------- Tab / Active tracking ---------------

let currentTrackedDomain = null;
let visitStartTime = null;

async function trackActiveTab() {
  try {
    const [tab] = await chrome.tabs.query({ active: true, lastFocusedWindow: true });
    if (!tab || !tab.url) return;

    const domain = getDomainFromUrl(tab.url);
    if (!domain) { currentTrackedDomain = null; return; }

    if (domain !== currentTrackedDomain) {
      currentTrackedDomain = domain;
      visitStartTime = Date.now();
    }

    const todayKey = getTodayKey();
    const {
      tracking  = {},
      blacklist = {},
      whitelist = {},
      settings  = DEFAULT_SETTINGS,
      prompted  = {},
      pomodoro,
      cooldowns = {}
    } = await getStorage(['tracking', 'blacklist', 'whitelist', 'settings', 'prompted', 'pomodoro', 'cooldowns']);

    // Accumulate time
    if (!tracking[todayKey])         tracking[todayKey] = {};
    if (!tracking[todayKey][domain]) tracking[todayKey][domain] = 0;
    tracking[todayKey][domain] += 15;
    await setStorage({ tracking });

    const totalMinutesToday = tracking[todayKey][domain] / 60;

    // --- Enforce blocks for blacklisted domains ---
    const blEnt = blEntry(blacklist, domain);
    if (blEnt) {
      const allowance = blEnt.dailyAllowance ?? settings.dailyAllowanceMinutes;
      const maxVisit  = blEnt.maxPerVisit    ?? settings.maxPerVisitMinutes;
      const normDomain = normaliseHostname(domain);

      // Pomodoro work block
      if (pomodoro && pomodoro.active && pomodoro.mode === 'work') {
        blockTab(tab.id, normDomain, 'pomodoro'); return;
      }

      // Cooldown block (per-visit limit was already hit)
      const cdEnd = cooldowns[normDomain] || cooldowns[domain];
      if (cdEnd && Date.now() < cdEnd) {
        blockTab(tab.id, normDomain, 'cooldown', cdEnd); return;
      }

      // Daily allowance exhausted
      if (totalMinutesToday >= allowance) {
        blockTab(tab.id, normDomain, 'daily'); return;
      }

      // Per-visit limit hit → start cooldown
      const visitMins = (Date.now() - (visitStartTime || Date.now())) / 60000;
      if (visitMins >= maxVisit) {
        const cooldownMs = settings.visitCooldownMinutes * 60 * 1000;
        const cooldownEnd = Date.now() + cooldownMs;
        cooldowns[normDomain] = cooldownEnd;
        await setStorage({ cooldowns });
        // Set alarm to auto-clear the cooldown
        chrome.alarms.create(`cooldown_${encodeURIComponent(normDomain)}`, { when: cooldownEnd });
        blockTab(tab.id, normDomain, 'cooldown', cooldownEnd); return;
      }
    }

    // --- Auto-block check for non-blacklisted domains ---
    if (!blEnt && settings.autoblockEnabled && !wlEntry(whitelist, domain)) {
      if (totalMinutesToday >= settings.autoblockMinutes) {
        const autoblockKey = `autoblock_${getTodayKey()}_${domain}`;
        const { prompted: pr = {} } = await getStorage('prompted');
        if (!pr[autoblockKey]) {
          pr[autoblockKey] = true;
          await setStorage({ prompted: pr });
          // Auto-add to blacklist using normalised key
          const normKey = normaliseHostname(domain);
          blacklist[normKey] = {
            dailyAllowance: settings.dailyAllowanceMinutes,
            maxPerVisit:    settings.maxPerVisitMinutes,
            addedAt:        Date.now(),
            autoBlocked:    true
          };
          await setStorage({ blacklist });
          await updateDeclarativeRules();
          sendNotification(
            '🚨 Site auto-blocked',
            `${normKey} has been added to the blacklist after ${Math.round(totalMinutesToday)} minutes of use today.`
          );
          blockTab(tab.id, normKey, 'daily'); return;
        }
      }
    }

    // --- Threshold prompt for non-blacklisted, non-whitelisted domains ---
    if (!blEnt && !wlEntry(whitelist, domain) && totalMinutesToday >= settings.thresholdMinutes) {
      const promptedKey = `${getTodayKey()}_${domain}`;
      const { prompted: pr = {} } = await getStorage('prompted');
      if (!pr[promptedKey]) {
        pr[promptedKey] = true;
        await setStorage({ prompted: pr });
        chrome.tabs.create({
          url: chrome.runtime.getURL(
            `prompt.html?domain=${encodeURIComponent(domain)}&minutes=${Math.round(totalMinutesToday)}`
          )
        });
      }
    }

    // Prune tracking to last 3 days
    const keys = Object.keys(tracking);
    if (keys.length > 3) {
      keys.sort();
      while (keys.length > 3) delete tracking[keys.shift()];
      await setStorage({ tracking });
    }

    // Update badge countdown every tick
    updateBadgeTimer(pomodoro);

  } catch (e) {
    console.error('The Authoritarian tracking error:', e);
  }
}

function blockTab(tabId, domain, reason, cooldownEnd) {
  let url = `blocked.html?domain=${encodeURIComponent(domain)}&reason=${reason}`;
  if (cooldownEnd) url += `&cooldownEnd=${cooldownEnd}`;
  chrome.tabs.update(tabId, { url: chrome.runtime.getURL(url) });
}

// --------------- declarativeNetRequest rules ---------------

async function updateDeclarativeRules() {
  try {
    const existingRules = await chrome.declarativeNetRequest.getDynamicRules();
    const removeRuleIds = existingRules.map(r => r.id);

    const { pomodoro, blacklist = {}, cooldowns = {} } = await getStorage(['pomodoro', 'blacklist', 'cooldowns']);
    const isWorkSession = pomodoro && pomodoro.active && pomodoro.mode === 'work';

    // Domains to block: blacklisted during work OR currently in cooldown
    const now = Date.now();
    const cooldownDomains = Object.keys(cooldowns).filter(d => cooldowns[d] > now);
    const workDomains = isWorkSession ? Object.keys(blacklist) : [];

    // Union of both sets
    const domainsToBlock = [...new Set([...workDomains, ...cooldownDomains])];

    if (domainsToBlock.length === 0) {
      if (removeRuleIds.length > 0) {
        await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds });
      }
      return;
    }

    const addRules = domainsToBlock.map((domain, i) => {
      const reason = (isWorkSession && blacklist[domain]) ? 'pomodoro' : 'cooldown';
      const extra  = reason === 'cooldown' ? `&cooldownEnd=${cooldowns[domain]}` : '';
      return {
        id:       i + 1,
        priority: 1,
        action: {
          type:     'redirect',
          redirect: {
            extensionPath: `/blocked.html?domain=${encodeURIComponent(domain)}&reason=${reason}${extra}`
          }
        },
        condition: {
          requestDomains: [domain],
          resourceTypes:  ['main_frame']
        }
      };
    });

    await chrome.declarativeNetRequest.updateDynamicRules({ removeRuleIds, addRules });
  } catch (e) {
    console.error('updateDeclarativeRules error:', e);
  }
}

async function blockAllBlacklistedTabs() {
  try {
    const { blacklist = {} } = await getStorage('blacklist');
    if (!Object.keys(blacklist).length) return;
    const tabs = await chrome.tabs.query({});
    for (const tab of tabs) {
      if (!tab.url) continue;
      const domain = getDomainFromUrl(tab.url);
      if (!domain) continue;
      const entry = blEntry(blacklist, domain);
      if (entry) {
        const normDomain = normaliseHostname(domain);
        try { await chrome.tabs.update(tab.id, { url: chrome.runtime.getURL(`blocked.html?domain=${encodeURIComponent(normDomain)}&reason=pomodoro`) }); } catch {}
      }
    }
  } catch (e) {
    console.error('blockAllBlacklistedTabs error:', e);
  }
}

chrome.tabs.onActivated.addListener(async (activeInfo) => {
  try {
    const tab = await chrome.tabs.get(activeInfo.tabId);
    if (!tab || !tab.url) return;

    const domain = getDomainFromUrl(tab.url);
    if (domain !== currentTrackedDomain) { currentTrackedDomain = domain; visitStartTime = Date.now(); }
    if (!domain) return;

    const { blacklist = {}, pomodoro, cooldowns = {}, settings = DEFAULT_SETTINGS } = await getStorage([
      'blacklist', 'pomodoro', 'cooldowns', 'settings'
    ]);

    const normDomain = normaliseHostname(domain);
    const cdEnd = cooldowns[normDomain] || cooldowns[domain];
    if (cdEnd && Date.now() < cdEnd) {
      blockTab(activeInfo.tabId, normDomain, 'cooldown', cdEnd); return;
    }

    const blEnt = blEntry(blacklist, domain);
    if (!blEnt) return;

    if (pomodoro && pomodoro.active && pomodoro.mode === 'work') {
      blockTab(activeInfo.tabId, normDomain, 'pomodoro'); return;
    }

    const todayKey = getTodayKey();
    const { tracking = {} } = await getStorage('tracking');
    const totalSeconds = (tracking[todayKey] && tracking[todayKey][domain]) || 0;
    const allowance = blEnt.dailyAllowance ?? settings.dailyAllowanceMinutes;
    if (totalSeconds / 60 >= allowance) blockTab(activeInfo.tabId, normDomain, 'daily');
  } catch {}
});

chrome.tabs.onUpdated.addListener(async (tabId, changeInfo, tab) => {
  if (!changeInfo.url) return;
  const domain = getDomainFromUrl(changeInfo.url);
  if (domain && domain !== currentTrackedDomain) { currentTrackedDomain = domain; visitStartTime = Date.now(); }
  if (!domain) return;

  const { blacklist = {}, pomodoro, cooldowns = {}, settings = DEFAULT_SETTINGS } = await getStorage([
    'blacklist', 'pomodoro', 'cooldowns', 'settings'
  ]);

  const normDomain = normaliseHostname(domain);
  const cdEnd = cooldowns[normDomain] || cooldowns[domain];
  if (cdEnd && Date.now() < cdEnd) {
    blockTab(tabId, normDomain, 'cooldown', cdEnd); return;
  }

  const blEnt = blEntry(blacklist, domain);
  if (blEnt) {
    if (pomodoro && pomodoro.active && pomodoro.mode === 'work') {
      blockTab(tabId, normDomain, 'pomodoro'); return;
    }
    const todayKey = getTodayKey();
    const { tracking = {} } = await getStorage('tracking');
    const totalSeconds = (tracking[todayKey] && tracking[todayKey][domain]) || 0;
    const allowance = blEnt.dailyAllowance ?? settings.dailyAllowanceMinutes;
    if (totalSeconds / 60 >= allowance) blockTab(tabId, normDomain, 'daily');
  }
});

// --------------- Pomodoro ---------------

async function handleFocusCheck() {
  const { pomodoro } = await getStorage('pomodoro');
  if (!pomodoro || !pomodoro.active || pomodoro.mode !== 'work') return;

  const tab = await chrome.tabs.create({
    url:    chrome.runtime.getURL(`focus-check.html?session=${(pomodoro.sessionCount || 0) + 1}`),
    active: true
  });

  // Bring Chrome window to the foreground so the check-in interrupts other apps
  try { chrome.windows.update(tab.windowId, { focused: true, drawAttention: true }); } catch {}

  await setStorage({ focusCheckTabId: tab.id });
  const now = Date.now();
  chrome.alarms.clear('focusCheckReminder');
  chrome.alarms.clear('focusCheckTimeout');
  chrome.alarms.create('focusCheckReminder', { when: now + 60 * 1000 });   // 1 min: nudge
  chrome.alarms.create('focusCheckTimeout',  { when: now + 120 * 1000 });  // 2 min: auto-resolve
}

async function handleFocusCheckTimeout() {
  const { focusCheckTabId } = await getStorage('focusCheckTabId');
  if (!focusCheckTabId) return; // already answered — nothing to do

  // Close the unanswered tab
  try { await chrome.tabs.remove(focusCheckTabId); } catch {}
  await setStorage({ focusCheckTabId: null });
  chrome.alarms.clear('focusCheckReminder');

  const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
  const action = settings.focusCheckTimeoutAction ?? DEFAULT_SETTINGS.focusCheckTimeoutAction;

  if (action === 'distracted') {
    sendNotification(
      'Focus check unanswered — DISTRACTED assumed.',
      'By order of the Ministry, your session has been restarted.'
    );
    const { pomodoro } = await getStorage('pomodoro');
    if (pomodoro && pomodoro.active && pomodoro.mode === 'work') {
      await clearFocusCheckAlarms();
      await startWorkSession(pomodoro.sessionCount || 0, settings);
    }
  } else {
    // 'focused' — trust the worker, session continues uninterrupted
    sendNotification(
      'Focus check unanswered — WORKING assumed.',
      'Session continues. The Ministry is watching.'
    );
  }
}

async function handleFocusCheckReminder() {
  const { focusCheckTabId } = await getStorage('focusCheckTabId');
  if (!focusCheckTabId) return;
  try {
    const tab = await chrome.tabs.get(focusCheckTabId);
    if (tab && tab.url && tab.url.includes('focus-check.html')) {
      sendNotification('⏰ Focus check waiting', 'Please answer the focus check to continue your session.');
      chrome.tabs.update(focusCheckTabId, { active: true });
      try { chrome.windows.update(tab.windowId, { focused: true }); } catch {}
    } else {
      await setStorage({ focusCheckTabId: null });
    }
  } catch {
    await setStorage({ focusCheckTabId: null });
  }
}

// Helper: clear all focusCheck_N alarms
async function clearFocusCheckAlarms() {
  const allAlarms = await chrome.alarms.getAll();
  for (const alarm of allAlarms) {
    if (alarm.name.startsWith('focusCheck_')) chrome.alarms.clear(alarm.name);
  }
  chrome.alarms.clear('focusCheckReminder');
  chrome.alarms.clear('focusCheckTimeout');
}

// customWorkMinutes: optional override for session length (used by focus-burst feature)
async function startWorkSession(sessionCount, settings, customWorkMinutes = null) {
  const totalWorkMins = customWorkMinutes ?? settings.pomodoroWorkMinutes;

  const workEnd = Date.now() + totalWorkMins * 60 * 1000;
  const now     = Date.now();

  await setStorage({
    pomodoro: { active: true, mode: 'work', endTime: workEnd, sessionCount },
    focusCheckTabId: null
  });
  chrome.alarms.create('pomodoroEnd', { when: workEnd });

  // Distribute check-ins evenly across the session
  await clearFocusCheckAlarms();
  const checkCount   = settings.focusCheckCount ?? DEFAULT_SETTINGS.focusCheckCount;
  const intervalMins = totalWorkMins / (checkCount + 1);
  for (let i = 1; i <= checkCount; i++) {
    const fireAt = now + intervalMins * i * 60 * 1000;
    if (fireAt < workEnd) chrome.alarms.create(`focusCheck_${i - 1}`, { when: fireAt });
  }

  await updateDeclarativeRules();
  await blockAllBlacklistedTabs();
  updateBadgeTimer({ active: true, mode: 'work', endTime: workEnd });
  return workEnd;
}

async function handlePomodoroEnd() {
  const { pomodoro } = await getStorage('pomodoro');
  if (!pomodoro || !pomodoro.active) return;
  const { settings = DEFAULT_SETTINGS } = await getStorage('settings');

  if (pomodoro.mode === 'work') {
    await clearFocusCheckAlarms();
    const sessionCount = (pomodoro.sessionCount || 0) + 1;
    const isLongBreak  = sessionCount % settings.sessionsBeforeLongBreak === 0;
    const breakMins    = isLongBreak ? settings.longBreakMinutes : settings.pomodoroBreakMinutes;
    const breakMode    = isLongBreak ? 'longbreak' : 'break';
    const breakEnd     = Date.now() + breakMins * 60 * 1000;
    // Daily break allowance — shared pool for the whole day, not per session
    const bonusCap = settings.breakBonusMinutes ?? DEFAULT_SETTINGS.breakBonusMinutes;
    const todayStr = getTodayKey();
    const { breakDailyPool } = await getStorage('breakDailyPool');
    let bonusRemaining;
    if (!breakDailyPool || breakDailyPool.date !== todayStr) {
      // New day (or first ever) — initialise the daily pool
      bonusRemaining = bonusCap;
      await setStorage({ breakDailyPool: { date: todayStr, remaining: bonusCap } });
    } else {
      // Carry over whatever is left in today's pool
      bonusRemaining = breakDailyPool.remaining;
    }

    // Record stats
    const { pomodoroStats = { totalSessions: 0, totalFocusMinutes: 0, totalBreakMinutes: 0, history: [] } } = await getStorage('pomodoroStats');
    const todayKey = getTodayKey();
    pomodoroStats.totalSessions++;
    pomodoroStats.totalFocusMinutes += settings.pomodoroWorkMinutes;
    // Update today's history entry
    const todayIdx = pomodoroStats.history.findIndex(h => h.date === todayKey);
    if (todayIdx >= 0) {
      pomodoroStats.history[todayIdx].sessions++;
      pomodoroStats.history[todayIdx].focusMinutes += settings.pomodoroWorkMinutes;
    } else {
      pomodoroStats.history.push({ date: todayKey, sessions: 1, focusMinutes: settings.pomodoroWorkMinutes, breakMinutes: 0 });
    }
    // Keep history to last 30 days
    if (pomodoroStats.history.length > 30) pomodoroStats.history.shift();
    await setStorage({ pomodoroStats });

    await setStorage({
      pomodoro: { active: true, mode: breakMode, endTime: breakEnd, sessionCount, breakBonusRemaining: bonusRemaining }
    });
    chrome.alarms.create('pomodoroEnd', { when: breakEnd });
    await updateDeclarativeRules();

    sendNotification(
      `Session ${sessionCount} complete!`,
      `${isLongBreak ? 'Long break' : 'Short break'} — ${breakMins} minutes. ${bonusRemaining > 0 ? `+${bonusRemaining} min bonus available.` : 'Stand at ease.'}`,
      breakEnd,
      isLongBreak ? 'longbreak' : 'break'
    );
    updateBadgeTimer({ active: true, mode: 'break', endTime: breakEnd });

  } else {
    // Record break minutes in stats
    if (pomodoro.endTime) {
      const { pomodoroStats = { totalSessions: 0, totalFocusMinutes: 0, totalBreakMinutes: 0, history: [] } } = await getStorage('pomodoroStats');
      const breakActual = Math.round((Date.now() - (pomodoro.endTime - (pomodoro.breakDuration || 0))) / 60000);
      pomodoroStats.totalBreakMinutes += breakActual;
      const todayKey = getTodayKey();
      const todayIdx = pomodoroStats.history.findIndex(h => h.date === todayKey);
      if (todayIdx >= 0) pomodoroStats.history[todayIdx].breakMinutes += breakActual;
      await setStorage({ pomodoroStats });
    }

    const sessionCount = pomodoro.sessionCount || 0;
    const nextWorkEnd  = await startWorkSession(sessionCount, settings);
    sendNotification(
      'Break over — return to post.',
      `Session ${sessionCount + 1} commencing. ${settings.pomodoroWorkMinutes} minutes of focus.`,
      nextWorkEnd,
      'work'
    );
  }
}

// --------------- Message handling ---------------

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  (async () => {
    try {
      switch (msg.type) {

        // ---- Pomodoro ----

        case 'startPomodoro': {
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          const workEnd0 = await startWorkSession(0, settings);
          sendNotification('Pomodoro commenced.', `Session 1 — ${settings.pomodoroWorkMinutes} minutes. The Ministry is watching.`, workEnd0, 'work');
          sendResponse({ success: true });
          break;
        }

        case 'stopPomodoro': {
          await setStorage({
            pomodoro: { active: false, mode: 'idle', endTime: null, sessionCount: 0 },
            focusCheckTabId: null
          });
          chrome.alarms.clear('pomodoroEnd');
          await clearFocusCheckAlarms();
          await updateDeclarativeRules();
          setBadge('', null);
          sendNotification('Session terminated.', 'Your Pomodoro session has been ended.');
          sendResponse({ success: true });
          break;
        }

        case 'restartSession': {
          const { pomodoro: pom } = await getStorage('pomodoro');
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          const sessionCount = pom ? (pom.sessionCount || 0) : 0;
          await clearFocusCheckAlarms();
          await setStorage({ focusCheckTabId: null });
          const restartEnd = await startWorkSession(sessionCount, settings);
          sendNotification('Session restarted.', `Fresh ${settings.pomodoroWorkMinutes} minutes. Discipline maintained.`, restartEnd, 'work');
          sendResponse({ success: true });
          break;
        }

        case 'earlyBreak': {
          const { pomodoro: pom } = await getStorage('pomodoro');
          if (!pom || !pom.active || pom.mode !== 'work') {
            sendResponse({ error: 'not_in_work' }); break;
          }
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          await clearFocusCheckAlarms();
          chrome.alarms.clear('pomodoroEnd');

          const sessionCount  = pom.sessionCount || 0;
          const isLongBreak   = sessionCount > 0 && sessionCount % (settings.sessionsBeforeLongBreak ?? DEFAULT_SETTINGS.sessionsBeforeLongBreak) === 0;
          const breakMins     = isLongBreak ? (settings.longBreakMinutes ?? DEFAULT_SETTINGS.longBreakMinutes) : (settings.pomodoroBreakMinutes ?? DEFAULT_SETTINGS.pomodoroBreakMinutes);
          const breakMode     = isLongBreak ? 'longbreak' : 'break';
          const breakEnd      = Date.now() + breakMins * 60 * 1000;

          // Use existing daily pool balance
          const bonusCap   = settings.breakBonusMinutes ?? DEFAULT_SETTINGS.breakBonusMinutes;
          const todayEb    = getTodayKey();
          const { breakDailyPool: ebPool } = await getStorage('breakDailyPool');
          const bonusLeft  = (!ebPool || ebPool.date !== todayEb) ? bonusCap : ebPool.remaining;

          await setStorage({
            pomodoro: { active: true, mode: breakMode, endTime: breakEnd, sessionCount, breakBonusRemaining: bonusLeft }
          });
          chrome.alarms.create('pomodoroEnd', { when: breakEnd });
          await updateDeclarativeRules();

          const reason = msg.reason ? `Reason: ${msg.reason}. ` : '';
          sendNotification('Early break granted.', `${reason}${isLongBreak ? 'Long break' : 'Break'} — ${breakMins} minutes.`, breakEnd, isLongBreak ? 'longbreak' : 'break');
          updateBadgeTimer({ active: true, mode: 'break', endTime: breakEnd });
          sendResponse({ success: true });
          break;
        }

        case 'skipBreak': {
          const { pomodoro: pom } = await getStorage('pomodoro');
          if (!pom || !pom.active || (pom.mode !== 'break' && pom.mode !== 'longbreak')) {
            sendResponse({ error: 'not_in_break' }); break;
          }
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          chrome.alarms.clear('pomodoroEnd');
          const skipEnd = await startWorkSession(pom.sessionCount || 0, settings);
          sendNotification('Break skipped.', `Session ${(pom.sessionCount || 0) + 1} commencing. The Ministry notes your dedication.`, skipEnd, 'work');
          sendResponse({ success: true });
          break;
        }

        case 'extendBreak': {
          const { pomodoro: pom } = await getStorage('pomodoro');
          if (!pom || !pom.active || (pom.mode !== 'break' && pom.mode !== 'longbreak')) {
            sendResponse({ error: 'Not in a break session.' }); break;
          }
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          const addMins = settings.extendBreakByMinutes ?? DEFAULT_SETTINGS.extendBreakByMinutes;

          // Read from daily pool (authoritative source)
          const todayStr2 = getTodayKey();
          const bonusCap2 = settings.breakBonusMinutes ?? DEFAULT_SETTINGS.breakBonusMinutes;
          const { breakDailyPool: pool2 } = await getStorage('breakDailyPool');
          const poolRemaining = (!pool2 || pool2.date !== todayStr2) ? bonusCap2 : pool2.remaining;

          if (poolRemaining < addMins) {
            sendResponse({ error: 'no_bonus', remaining: poolRemaining }); break;
          }
          const newRemaining = poolRemaining - addMins;
          await setStorage({ breakDailyPool: { date: todayStr2, remaining: newRemaining } });

          const newEndTime = pom.endTime + addMins * 60 * 1000;
          await setStorage({ pomodoro: { ...pom, endTime: newEndTime, breakBonusRemaining: newRemaining } });
          chrome.alarms.clear('pomodoroEnd');
          chrome.alarms.create('pomodoroEnd', { when: newEndTime });
          updateBadgeTimer({ active: true, mode: pom.mode, endTime: newEndTime });
          sendResponse({ success: true, newEndTime, breakBonusRemaining: newRemaining });
          break;
        }

        case 'extendWork': {
          // Queue extra focus minutes to be added to the next work session (usable during break)
          const { pomodoro: pom } = await getStorage('pomodoro');
          if (!pom || !pom.active || (pom.mode !== 'break' && pom.mode !== 'longbreak')) {
            sendResponse({ error: 'not_in_break' }); break;
          }
          const addMins = msg.minutes || 5;
          const current = pom.focusExtensionMinutes || 0;
          const updated  = current + addMins;
          await setStorage({ pomodoro: { ...pom, focusExtensionMinutes: updated } });
          sendResponse({ success: true, focusExtensionMinutes: updated });
          break;
        }

        case 'getPomodoroStats': {
          const { pomodoroStats = { totalSessions: 0, totalFocusMinutes: 0, totalBreakMinutes: 0, history: [] } } = await getStorage('pomodoroStats');
          sendResponse(pomodoroStats);
          break;
        }

        case 'focusCheckAnswered': {
          chrome.alarms.clear('focusCheckReminder');
          chrome.alarms.clear('focusCheckTimeout');
          await setStorage({ focusCheckTabId: null });
          sendResponse({ success: true });
          break;
        }

        case 'getPomodoroState': {
          const { pomodoro } = await getStorage('pomodoro');
          if (!pomodoro) { sendResponse({ active: false, mode: 'idle', endTime: null, sessionCount: 0 }); break; }
          // Always surface the live daily pool remaining so the popup stays accurate
          const { settings: s2 = DEFAULT_SETTINGS } = await getStorage('settings');
          const { breakDailyPool: dp } = await getStorage('breakDailyPool');
          const todayDp = getTodayKey();
          const bonusDp = s2.breakBonusMinutes ?? DEFAULT_SETTINGS.breakBonusMinutes;
          const liveRemaining = (!dp || dp.date !== todayDp) ? bonusDp : dp.remaining;
          sendResponse({ ...pomodoro, breakBonusRemaining: liveRemaining });
          break;
        }

        // ---- Blacklist ----

        case 'addToBlacklist': {
          if (await isLocked()) { sendResponse({ error: 'locked' }); break; }
          const { blacklist = {}, settings = DEFAULT_SETTINGS } = await getStorage(['blacklist', 'settings']);
          blacklist[msg.domain] = {
            dailyAllowance: settings.dailyAllowanceMinutes,
            maxPerVisit:    settings.maxPerVisitMinutes,
            addedAt:        Date.now()
          };
          await setStorage({ blacklist });
          await updateDeclarativeRules();
          sendResponse({ success: true });
          break;
        }

        case 'removeFromBlacklist': {
          if (await isLocked()) { sendResponse({ error: 'locked' }); break; }
          const { blacklist = {} } = await getStorage('blacklist');
          delete blacklist[msg.domain];
          await setStorage({ blacklist });
          await updateDeclarativeRules();
          sendResponse({ success: true });
          break;
        }

        case 'getBlacklist': {
          const { blacklist = {} } = await getStorage('blacklist');
          sendResponse(blacklist);
          break;
        }

        case 'updateBlacklistEntry': {
          if (await isLocked()) { sendResponse({ error: 'locked' }); break; }
          const { blacklist = {} } = await getStorage('blacklist');
          if (blacklist[msg.domain]) {
            if (msg.dailyAllowance !== undefined) blacklist[msg.domain].dailyAllowance = msg.dailyAllowance;
            if (msg.maxPerVisit    !== undefined) blacklist[msg.domain].maxPerVisit    = msg.maxPerVisit;
            await setStorage({ blacklist });
          }
          sendResponse({ success: true });
          break;
        }

        // ---- Whitelist ----

        case 'addToWhitelist': {
          if (await isLocked()) { sendResponse({ error: 'locked' }); break; }
          const { whitelist = {} } = await getStorage('whitelist');
          whitelist[msg.domain] = { addedAt: Date.now() };
          await setStorage({ whitelist });
          sendResponse({ success: true });
          break;
        }

        case 'removeFromWhitelist': {
          if (await isLocked()) { sendResponse({ error: 'locked' }); break; }
          const { whitelist = {} } = await getStorage('whitelist');
          delete whitelist[msg.domain];
          await setStorage({ whitelist });
          sendResponse({ success: true });
          break;
        }

        case 'getWhitelist': {
          const { whitelist = {} } = await getStorage('whitelist');
          sendResponse(whitelist);
          break;
        }

        // ---- Cooldowns ----

        case 'getCooldowns': {
          const { cooldowns = {} } = await getStorage('cooldowns');
          sendResponse(cooldowns);
          break;
        }

        // ---- Settings ----

        case 'getSettings': {
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          sendResponse(settings);
          break;
        }

        case 'updateSettings': {
          if (await isLocked()) { sendResponse({ error: 'locked' }); break; }
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          Object.assign(settings, msg.settings);
          await setStorage({ settings });
          sendResponse({ success: true });
          break;
        }

        // ---- Tracking ----

        case 'getTracking': {
          const { tracking = {} } = await getStorage('tracking');
          sendResponse(tracking[getTodayKey()] || {});
          break;
        }

        // ---- Settings Lock ----

        case 'getLockState': {
          const { settingsLocked = false, unlockRequest = null } = await getStorage(['settingsLocked', 'unlockRequest']);
          sendResponse({ settingsLocked, unlockRequest });
          break;
        }

        case 'lockSettings': {
          await setStorage({ settingsLocked: true, unlockRequest: null });
          sendResponse({ success: true });
          break;
        }

        case 'requestUnlock': {
          // Begins the unlock process — records the timestamp + word count requirement
          const { settings = DEFAULT_SETTINGS } = await getStorage('settings');
          const unlockRequest = {
            requestedAt: Date.now(),
            minWaitMs:   settings.lockMinWaitMinutes * 60 * 1000,
            minWords:    settings.lockMinWords,
            reasoning:   ''
          };
          await setStorage({ unlockRequest });
          sendResponse({ success: true, unlockRequest });
          break;
        }

        case 'submitUnlock': {
          // msg.reasoning — the typed text; validated here
          const { settingsLocked, unlockRequest, settings = DEFAULT_SETTINGS } = await getStorage([
            'settingsLocked', 'unlockRequest', 'settings'
          ]);
          if (!settingsLocked) { sendResponse({ success: true }); break; }
          if (!unlockRequest)  { sendResponse({ error: 'No unlock request found. Please start over.' }); break; }

          const elapsed = Date.now() - unlockRequest.requestedAt;
          const minWait = settings.lockMinWaitMinutes * 60 * 1000;
          if (elapsed < minWait) {
            const remaining = Math.ceil((minWait - elapsed) / 1000);
            sendResponse({ error: 'wait', remaining });
            break;
          }

          const wordCount = (msg.reasoning || '').trim().split(/\s+/).filter(Boolean).length;
          if (wordCount < settings.lockMinWords) {
            sendResponse({ error: 'words', required: settings.lockMinWords, current: wordCount });
            break;
          }

          await setStorage({ settingsLocked: false, unlockRequest: null });
          sendResponse({ success: true });
          break;
        }

        default:
          sendResponse({ error: 'Unknown message type' });
      }
    } catch (e) {
      console.error('Message handler error:', e);
      sendResponse({ error: e.message });
    }
  })();
  return true;
});
