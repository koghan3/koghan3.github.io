// ==========================================
// The Authoritarian — Lock/Unlock page
// ==========================================

function sendMsg(msg) {
  return new Promise(resolve => chrome.runtime.sendMessage(msg, resolve));
}

const $ = id => document.getElementById(id);

let isLocked = false;
let unlockRequest = null;
let minWords = 50;
let minWaitMs = 3 * 60 * 1000;
let countdownInterval = null;
let wordsDone = false;
let waitDone  = false;

// ---- Render status ----

async function init() {
  const settings = await sendMsg({ type: 'getSettings' });
  if (settings) {
    minWords  = settings.lockMinWords     || 50;
    minWaitMs = settings.lockMinWaitMinutes * 60 * 1000 || 3 * 60 * 1000;
  }

  $('minWordsLabel').textContent = minWords;
  $('wordCount').textContent     = `0 / ${minWords} words`;

  const state = await sendMsg({ type: 'getLockState' });
  if (!state) return;

  isLocked      = state.settingsLocked;
  unlockRequest = state.unlockRequest;

  renderLockState();
}

function renderLockState() {
  const statusVal = $('statusValue');
  const lockActionBtn = $('lockActionBtn');

  if (isLocked) {
    statusVal.textContent = 'LOCKED';
    statusVal.className   = 'status-value status-locked';
    $('unlockFlow').style.display = 'block';
    $('unlockedState').classList.remove('show');

    // Create unlock request if none exists
    if (!unlockRequest) {
      sendMsg({ type: 'requestUnlock' }).then(resp => {
        if (resp && resp.unlockRequest) {
          unlockRequest = resp.unlockRequest;
          startCountdown();
        }
      });
    } else {
      startCountdown();
    }

    lockActionBtn.innerHTML = '';

  } else {
    statusVal.textContent = 'UNLOCKED';
    statusVal.className   = 'status-value status-unlocked';
    $('unlockFlow').style.display = 'none';
    $('unlockedState').classList.add('show');
    lockActionBtn.innerHTML = '';
  }
}

// ---- Countdown timer ----

function startCountdown() {
  if (!unlockRequest) return;

  const updateCountdown = () => {
    const elapsed   = Date.now() - unlockRequest.requestedAt;
    const remaining = Math.max(0, minWaitMs - elapsed);
    const m = Math.floor(remaining / 60000);
    const s = Math.floor((remaining % 60000) / 1000);

    $('countdownNum').textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;

    if (remaining <= 0) {
      clearInterval(countdownInterval);
      $('countdownSection').classList.add('countdown-done');
      $('waitInfo').textContent = 'Waiting period complete. Submit your justification to unlock.';
      waitDone = true;
      checkCanSubmit();
    } else {
      waitDone = false;
      $('waitInfo').textContent = 'Waiting period in progress. You may begin typing your justification.';
    }
  };

  updateCountdown();
  countdownInterval = setInterval(updateCountdown, 1000);
}

// ---- Word counter ----

const textarea    = $('reasoning');
const wordCountEl = $('wordCount');
const progressFill = $('progressFill');
const submitBtn   = $('btnSubmit');

textarea.addEventListener('paste', e => {
  e.preventDefault();
  $('noPasteMsg').style.display = 'block';
  setTimeout(() => { $('noPasteMsg').style.display = 'none'; }, 3000);
});
textarea.addEventListener('drop', e => e.preventDefault());

textarea.addEventListener('input', () => {
  const words = textarea.value.trim().split(/\s+/).filter(w => w.length > 0);
  const count = words.length;
  const pct   = Math.min(100, (count / minWords) * 100);

  wordCountEl.textContent  = `${count} / ${minWords} words`;
  progressFill.style.width = `${pct}%`;

  if (count >= minWords) {
    wordCountEl.className      = 'word-count done';
    progressFill.className     = 'progress-fill done';
    wordsDone = true;
  } else if (count >= Math.floor(minWords / 2)) {
    wordCountEl.className  = 'word-count mid';
    progressFill.className = 'progress-fill amber';
    wordsDone = false;
  } else {
    wordCountEl.className  = 'word-count low';
    progressFill.className = 'progress-fill';
    wordsDone = false;
  }

  checkCanSubmit();
});

function checkCanSubmit() {
  $('errorMsg').textContent = '';

  if (wordsDone && waitDone) {
    submitBtn.disabled = false;
    submitBtn.classList.add('ready');
    submitBtn.textContent = 'SUBMIT PETITION — UNLOCK';
  } else if (!wordsDone && !waitDone) {
    submitBtn.disabled = true;
    submitBtn.classList.remove('ready');
    submitBtn.textContent = 'Complete wait & write justification';
  } else if (!wordsDone) {
    submitBtn.disabled = true;
    submitBtn.classList.remove('ready');
    submitBtn.textContent = `Write ${minWords} words to proceed`;
  } else {
    submitBtn.disabled = true;
    submitBtn.classList.remove('ready');
    submitBtn.textContent = 'Waiting period not yet complete';
  }
}

// ---- Submit unlock ----

submitBtn.addEventListener('click', async () => {
  const reasoning = textarea.value;
  const resp = await sendMsg({ type: 'submitUnlock', reasoning });

  if (!resp) return;

  if (resp.success) {
    // Show success
    $('unlockFlow').style.display = 'none';
    $('successPanel').classList.add('show');
    if (countdownInterval) clearInterval(countdownInterval);
  } else if (resp.error === 'wait') {
    const secs = resp.remaining;
    $('errorMsg').textContent = `WAIT ${secs} MORE SECONDS BEFORE SUBMITTING.`;
  } else if (resp.error === 'words') {
    $('errorMsg').textContent = `INSUFFICIENT JUSTIFICATION. ${resp.required - resp.current} MORE WORDS REQUIRED.`;
  } else {
    $('errorMsg').textContent = resp.error || 'An error occurred. Please try again.';
  }
});

// ---- Lock button (unlocked state) ----

$('btnLock').addEventListener('click', async () => {
  if (!confirm('Engage security lock? Unlocking will require a waiting period and written justification.')) return;
  await sendMsg({ type: 'lockSettings' });
  isLocked = true;
  unlockRequest = null;
  renderLockState();
  // Immediately request an unlock ticket so the timer starts
  const resp = await sendMsg({ type: 'requestUnlock' });
  if (resp && resp.unlockRequest) {
    unlockRequest = resp.unlockRequest;
    startCountdown();
  }
});

// ---- Init ----
init();
