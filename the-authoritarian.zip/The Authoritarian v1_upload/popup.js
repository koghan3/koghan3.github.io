// ==========================================
// The Authoritarian - Popup Controller
// ==========================================

const $ = (sel) => document.querySelector(sel);
const $$ = (sel) => document.querySelectorAll(sel);

// Track whether the early-break form is currently open so the 1-second
// interval refresh doesn't collapse it mid-input.
let earlyBreakFormOpen = false;

// --- Message helper ---
function sendMsg(msg) {
  return new Promise((resolve) => {
    chrome.runtime.sendMessage(msg, (response) => {
      resolve(response);
    });
  });
}

// --- Utility ---
function normaliseDomain(raw) {
  raw = raw.trim().toLowerCase();
  raw = raw.replace(/^https?:\/\//, '').replace(/^www\./, '');
  raw = raw.split('/')[0];
  return raw;
}

function isValidDomain(d) {
  return /^[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?(\.[a-z0-9]([a-z0-9\-]{0,61}[a-z0-9])?)+$/.test(d);
}

function formatTime(ms) {
  if (ms <= 0) return '00:00';
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
}

// --- Lock state ---
let isLocked = false;

async function checkLockState() {
  const resp = await sendMsg({ type: 'getLockState' });
  if (!resp) return;
  isLocked = resp.settingsLocked;

  const lockStatus = $('#lockStatus');
  const lockBtn = $('#lockSettingsBtn');
  const unlockBtn = $('#unlockSettingsBtn');
  const headerBtn = $('#headerLockBtn');

  if (isLocked) {
    lockStatus.textContent = 'STATUS: LOCKED';
    lockStatus.className = 'lock-status locked';
    lockBtn.style.display = 'none';
    unlockBtn.style.display = 'inline-block';
    headerBtn.textContent = 'LOCKED';
    headerBtn.classList.add('locked');
    $('#settings').classList.add('settings-locked');
    $('#blacklist').classList.add('settings-locked');
    $('#whitelist').classList.add('settings-locked');
  } else {
    lockStatus.textContent = 'STATUS: UNLOCKED';
    lockStatus.className = 'lock-status unlocked';
    lockBtn.style.display = 'inline-block';
    unlockBtn.style.display = 'none';
    headerBtn.textContent = 'LOCK';
    headerBtn.classList.remove('locked');
    $('#settings').classList.remove('settings-locked');
    $('#blacklist').classList.remove('settings-locked');
    $('#whitelist').classList.remove('settings-locked');
  }
}

function showLockOverlay() {
  $('#lockOverlay').classList.add('show');
}

// Close overlay on background click
$('#lockOverlay').addEventListener('click', (e) => {
  if (e.target === $('#lockOverlay')) {
    $('#lockOverlay').classList.remove('show');
  }
});

$('#overlayUnlockBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('lock-unlock.html') });
  window.close();
});

$('#lockSettingsBtn').addEventListener('click', async () => {
  if (!confirm('Lock all settings, blacklist, and whitelist? Unlocking requires a waiting period.')) return;
  await sendMsg({ type: 'lockSettings' });
  await checkLockState();
});

$('#unlockSettingsBtn').addEventListener('click', () => {
  chrome.tabs.create({ url: chrome.runtime.getURL('lock-unlock.html') });
  window.close();
});

$('#headerLockBtn').addEventListener('click', async () => {
  if (isLocked) {
    chrome.tabs.create({ url: chrome.runtime.getURL('lock-unlock.html') });
    window.close();
  } else {
    if (!confirm('Lock all settings and lists? Unlocking requires a waiting period.')) return;
    await sendMsg({ type: 'lockSettings' });
    await checkLockState();
  }
});

// Guard: show overlay if locked when clicking certain areas
function guardLocked() {
  if (isLocked) { showLockOverlay(); return true; }
  return false;
}

// --- Tab switching ---
$$('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    $$('.tab').forEach(t => t.classList.remove('active'));
    $$('.section').forEach(s => s.classList.remove('active'));
    tab.classList.add('active');
    $(`#${tab.dataset.tab}`).classList.add('active');

    const section = tab.dataset.tab;
    if (section === 'tracking')  loadTracking();
    if (section === 'blacklist') loadBlacklist();
    if (section === 'whitelist') loadWhitelist();
    if (section === 'settings')  { loadSettings(); checkLockState(); }
  });
});

// --- Pomodoro ---
async function loadStats() {
  const resp = await sendMsg({ type: 'getPomodoroStats' });
  if (!resp) return;

  const today = new Date().toISOString().slice(0, 10);
  const todayEntry = (resp.history || []).find(h => h.date === today);

  $('#statSessions').textContent = todayEntry ? todayEntry.sessions     : 0;
  $('#statFocusMin').textContent = todayEntry ? todayEntry.focusMinutes : 0;
  $('#statBreakMin').textContent = todayEntry ? todayEntry.breakMinutes : 0;
}

async function updatePomodoroUI() {
  const state = await sendMsg({ type: 'getPomodoroState' });
  if (!state) return;

  const modeEl         = $('#pomoMode');
  const timerEl        = $('#pomoTimer');
  const sessionEl      = $('#pomoSession');
  const earlyBreakPanel = $('#earlyBreakPanel');
  const breakCtrlPanel  = $('#breakControlPanel');

  if (state.active && state.endTime) {
    const remaining = state.endTime - Date.now();
    timerEl.textContent = formatTime(remaining);

    const settings     = await sendMsg({ type: 'getSettings' });
    const sessionsDone = state.sessionCount || 0;
    const sessionsMax  = (settings && settings.sessionsBeforeLongBreak) || 4;
    const isBreak      = state.mode === 'break' || state.mode === 'longbreak';

    if (state.mode === 'work') {
      modeEl.textContent = 'FOCUS SESSION';
      modeEl.className   = 'pomo-mode work';
      const sessInCycle  = (sessionsDone % sessionsMax) + 1;
      sessionEl.textContent = `SESSION ${sessInCycle} OF ${sessionsMax}  ·  TOTAL: ${sessionsDone + 1}`;
    } else if (state.mode === 'longbreak') {
      modeEl.textContent = 'LONG BREAK';
      modeEl.className   = 'pomo-mode longbreak';
      sessionEl.textContent = `${sessionsDone} SESSIONS COMPLETED`;
    } else {
      modeEl.textContent = 'SHORT BREAK';
      modeEl.className   = 'pomo-mode break';
      const sessInCycle  = sessionsDone % sessionsMax;
      sessionEl.textContent = `${sessInCycle} OF ${sessionsMax} BEFORE LONG BREAK`;
    }

    if (isBreak) {
      breakCtrlPanel.classList.add('show');
      earlyBreakPanel.classList.remove('show');
      const bonusLeft = state.breakBonusRemaining ?? 0;
      $('#bonusRemaining').textContent = bonusLeft;
      const extBy = (settings && settings.extendBreakByMinutes) || 1;
      $('#extendByLabel').textContent = extBy;
      $('#focusQueuedLabel').textContent = state.focusExtensionMinutes ?? 0;
    } else {
      breakCtrlPanel.classList.remove('show');
      earlyBreakPanel.classList.add('show');
      // Only reset the early break form if it isn't currently open
      // (prevents the 1-second interval from collapsing it mid-input)
      if (!earlyBreakFormOpen) {
        $('#earlyBreakForm').style.display   = 'none';
        $('#earlyBreakPrompt').style.display = 'block';
        $('#earlyBreakReason').value = '';
      }
    }

    $('#pomoStart').style.display = 'none';
    $('#pomoStop').style.display  = 'inline-block';
  } else {
    const settings = await sendMsg({ type: 'getSettings' });
    const mins = (settings && settings.pomodoroWorkMinutes) || 25;
    timerEl.textContent   = `${String(mins).padStart(2, '0')}:00`;
    modeEl.textContent    = 'IDLE';
    modeEl.className      = 'pomo-mode';
    sessionEl.textContent = '';
    earlyBreakPanel.classList.remove('show');
    breakCtrlPanel.classList.remove('show');
    $('#pomoStart').style.display = 'inline-block';
    $('#pomoStop').style.display  = 'none';
  }
}

$('#pomoStart').addEventListener('click', async () => {
  await sendMsg({ type: 'startPomodoro' });
  updatePomodoroUI();
  loadStats();
});
$('#pomoStop').addEventListener('click', async () => {
  await sendMsg({ type: 'stopPomodoro' });
  updatePomodoroUI();
  loadStats();
});

// Early break
$('#earlyBreakBtn').addEventListener('click', () => {
  earlyBreakFormOpen = true;
  $('#earlyBreakPrompt').style.display = 'none';
  $('#earlyBreakForm').style.display   = 'block';
  $('#earlyBreakReason').focus();
});
$('#earlyBreakCancel').addEventListener('click', () => {
  earlyBreakFormOpen = false;
  $('#earlyBreakForm').style.display   = 'none';
  $('#earlyBreakPrompt').style.display = 'block';
  $('#earlyBreakReason').value = '';
});
$('#earlyBreakConfirm').addEventListener('click', async () => {
  const reason = $('#earlyBreakReason').value.trim();
  if (!reason) { $('#earlyBreakReason').focus(); return; }
  earlyBreakFormOpen = false;
  await sendMsg({ type: 'earlyBreak', reason });
  updatePomodoroUI();
});

// Skip break
$('#skipBreakBtn').addEventListener('click', async () => {
  await sendMsg({ type: 'skipBreak' });
  updatePomodoroUI();
  loadStats();
});

$('#extendBreakBtn').addEventListener('click', async () => {
  const resp = await sendMsg({ type: 'extendBreak' });
  if (!resp) return;
  if (resp.error === 'no_bonus') {
    const bonusEl = $('#bonusRemaining');
    bonusEl.textContent = '0';
    bonusEl.style.color = 'var(--stamp)';
    setTimeout(() => { bonusEl.style.color = ''; }, 1500);
    return;
  }
  if (resp.success) {
    $('#bonusRemaining').textContent = resp.breakBonusRemaining ?? 0;
  }
});

// Focus extension buttons (shown during break)
async function handleExtendWork(minutes) {
  const resp = await sendMsg({ type: 'extendWork', minutes });
  if (resp && resp.success) {
    $('#focusQueuedLabel').textContent = resp.focusExtensionMinutes ?? minutes;
  }
}
$('#extendWork5Btn').addEventListener('click',  () => handleExtendWork(5));
$('#extendWork10Btn').addEventListener('click', () => handleExtendWork(10));

setInterval(updatePomodoroUI, 1000);

// --- Tracking ---
async function loadTracking() {
  const data     = await sendMsg({ type: 'getTracking' });
  const settings = await sendMsg({ type: 'getSettings' });
  const blacklist = await sendMsg({ type: 'getBlacklist' });
  const container = $('#trackList');

  // Date label
  const today = new Date();
  $('#trackDate').textContent = today.toISOString().slice(0, 10);

  if (!data || Object.keys(data).length === 0) {
    container.innerHTML = '<div class="empty-state">No records today.</div>';
    return;
  }

  const sorted     = Object.entries(data).sort((a, b) => b[1] - a[1]);
  const maxSeconds = sorted[0][1];

  container.innerHTML = sorted.map(([domain, seconds]) => {
    const minutes     = (seconds / 60).toFixed(1);
    const pct         = Math.min(100, (seconds / Math.max(maxSeconds, 1)) * 100);
    const isBlacklisted = !!(blacklist && blacklist[domain]);
    const threshold   = (settings && settings.thresholdMinutes) || 30;
    const barColor    = isBlacklisted ? '#7a1010' :
      seconds / 60 >= threshold ? '#b87c2a' : '#4a6230';
    const prefix = isBlacklisted ? '[BL] ' : '';

    return `
      <div class="track-item">
        <div style="flex:1;min-width:0">
          <div class="track-domain">${prefix}${domain}</div>
          <div class="track-bar">
            <div class="track-bar-fill" style="width:${pct}%;background:${barColor}"></div>
          </div>
        </div>
        <div class="track-time">${minutes}m</div>
      </div>
    `;
  }).join('');
}

// --- Blacklist ---
async function loadBlacklist() {
  const blacklist = await sendMsg({ type: 'getBlacklist' });
  const container = $('#blacklistItems');

  if (!blacklist || Object.keys(blacklist).length === 0) {
    container.innerHTML = '<div class="empty-state">Blacklist is empty.</div>';
    return;
  }

  container.innerHTML = Object.entries(blacklist).map(([domain, config]) => `
    <div class="list-item" data-domain="${domain}">
      <div class="list-item-header">
        <span class="list-domain blacklisted">${domain}</span>
        <button class="btn btn-neutral" style="font-size:13px;padding:4px 10px;" data-action="remove-bl" data-domain="${domain}">UNBLOCK</button>
      </div>
      <div class="list-meta">${config.autoBlocked ? 'AUTO-BLOCKED  |  ' : ''}ADDED ${new Date(config.addedAt).toLocaleDateString()}</div>
      <div class="list-controls">
        <label>Daily:
          <input type="number" class="num-input bl-allowance" value="${config.dailyAllowance}" min="1" max="480" data-domain="${domain}"> min
        </label>
        <label>Per visit:
          <input type="number" class="num-input bl-pervisit" value="${config.maxPerVisit}" min="1" max="120" data-domain="${domain}"> min
        </label>
      </div>
    </div>
  `).join('');

  container.querySelectorAll('[data-action="remove-bl"]').forEach(btn => {
    btn.addEventListener('click', () => {
      if (guardLocked()) return;
      chrome.tabs.create({ url: chrome.runtime.getURL(`unblock.html?domain=${encodeURIComponent(btn.dataset.domain)}`) });
    });
  });

  container.querySelectorAll('.bl-allowance').forEach(input => {
    input.addEventListener('change', () => {
      if (guardLocked()) return;
      sendMsg({ type: 'updateBlacklistEntry', domain: input.dataset.domain, dailyAllowance: parseInt(input.value) });
    });
  });
  container.querySelectorAll('.bl-pervisit').forEach(input => {
    input.addEventListener('change', () => {
      if (guardLocked()) return;
      sendMsg({ type: 'updateBlacklistEntry', domain: input.dataset.domain, maxPerVisit: parseInt(input.value) });
    });
  });
}

async function handleBlacklistAdd() {
  if (guardLocked()) return;
  const input  = $('#blAddInput');
  const errorEl = $('#blAddError');
  const domain = normaliseDomain(input.value);
  errorEl.textContent = '';

  if (!domain) { errorEl.textContent = 'ENTER A DOMAIN.'; return; }
  if (!isValidDomain(domain)) { errorEl.textContent = 'INVALID FORMAT. E.G.: reddit.com'; return; }

  const bl = await sendMsg({ type: 'getBlacklist' });
  if (bl && bl[domain]) { errorEl.textContent = `${domain.toUpperCase()} ALREADY BLACKLISTED.`; return; }

  await sendMsg({ type: 'addToBlacklist', domain });
  input.value = '';
  loadBlacklist();
}

$('#blAddBtn').addEventListener('click', handleBlacklistAdd);
$('#blAddInput').addEventListener('keydown', e => { if (e.key === 'Enter') handleBlacklistAdd(); });

// --- Whitelist ---
async function loadWhitelist() {
  const whitelist = await sendMsg({ type: 'getWhitelist' });
  const container = $('#whitelistItems');

  if (!whitelist || Object.keys(whitelist).length === 0) {
    container.innerHTML = '<div class="empty-state">No exempt domains.</div>';
    return;
  }

  container.innerHTML = Object.entries(whitelist).map(([domain, config]) => `
    <div class="list-item">
      <div class="list-item-header">
        <span class="list-domain whitelisted">${domain}</span>
        <button class="btn btn-neutral" style="font-size:13px;padding:4px 10px;" data-action="remove-wl" data-domain="${domain}">REMOVE</button>
      </div>
      <div class="list-meta">EXEMPT SINCE ${new Date(config.addedAt).toLocaleDateString()}</div>
    </div>
  `).join('');

  container.querySelectorAll('[data-action="remove-wl"]').forEach(btn => {
    btn.addEventListener('click', async () => {
      if (guardLocked()) return;
      await sendMsg({ type: 'removeFromWhitelist', domain: btn.dataset.domain });
      loadWhitelist();
    });
  });
}

async function handleWhitelistAdd() {
  if (guardLocked()) return;
  const input   = $('#wlAddInput');
  const errorEl = $('#wlAddError');
  const domain  = normaliseDomain(input.value);
  errorEl.textContent = '';

  if (!domain) { errorEl.textContent = 'ENTER A DOMAIN.'; return; }
  if (!isValidDomain(domain)) { errorEl.textContent = 'INVALID FORMAT. E.G.: google.com'; return; }

  const wl = await sendMsg({ type: 'getWhitelist' });
  if (wl && wl[domain]) { errorEl.textContent = `${domain.toUpperCase()} ALREADY EXEMPT.`; return; }

  await sendMsg({ type: 'addToWhitelist', domain });
  input.value = '';
  loadWhitelist();
}

$('#wlAddBtn').addEventListener('click', handleWhitelistAdd);
$('#wlAddInput').addEventListener('keydown', e => { if (e.key === 'Enter') handleWhitelistAdd(); });

// --- Settings ---
let autoblockEnabled = false;

async function loadSettings() {
  const s = await sendMsg({ type: 'getSettings' });
  if (!s) return;

  $('#setWork').value         = s.pomodoroWorkMinutes;
  $('#setBreak').value        = s.pomodoroBreakMinutes;
  $('#setLongBreak').value    = s.longBreakMinutes;
  $('#setSessionsLong').value = s.sessionsBeforeLongBreak;
  $('#setThreshold').value    = s.thresholdMinutes;
  $('#setAutoblock').value    = s.autoblockMinutes;
  $('#setCooldown').value     = s.visitCooldownMinutes;
  $('#setBreakBonus').value      = s.breakBonusMinutes       ?? 10;
  $('#setExtendBreakBy').value   = s.extendBreakByMinutes    ?? 1;
  $('#setTimeoutAction').value   = s.focusCheckTimeoutAction ?? 'distracted';
  $('#setFocusCheckCount').value = s.focusCheckCount         ?? 1;

  autoblockEnabled = s.autoblockEnabled;
  const toggle = $('#toggleAutoblock');
  if (autoblockEnabled) toggle.classList.add('on');
  else toggle.classList.remove('on');
}

$('#toggleAutoblock').addEventListener('click', () => {
  if (guardLocked()) return;
  autoblockEnabled = !autoblockEnabled;
  const toggle = $('#toggleAutoblock');
  if (autoblockEnabled) toggle.classList.add('on');
  else toggle.classList.remove('on');
});

$('#saveSettings').addEventListener('click', async () => {
  if (guardLocked()) return;

  const resp = await sendMsg({
    type: 'updateSettings',
    settings: {
      pomodoroWorkMinutes:     parseInt($('#setWork').value)          || 25,
      pomodoroBreakMinutes:    parseInt($('#setBreak').value)         || 5,
      longBreakMinutes:        parseInt($('#setLongBreak').value)     || 20,
      sessionsBeforeLongBreak: parseInt($('#setSessionsLong').value)  || 4,
      focusCheckCount:            parseInt($('#setFocusCheckCount').value) ?? 1,
      focusCheckTimeoutAction:    $('#setTimeoutAction').value || 'distracted',
      breakBonusMinutes:       parseInt($('#setBreakBonus').value)    ?? 10,
      extendBreakByMinutes:    parseInt($('#setExtendBreakBy').value) || 1,
      thresholdMinutes:        parseInt($('#setThreshold').value)     || 30,
      autoblockMinutes:        parseInt($('#setAutoblock').value)     || 60,
      visitCooldownMinutes:    parseInt($('#setCooldown').value)      || 5,
      autoblockEnabled
    }
  });

  if (resp && resp.error === 'locked') { showLockOverlay(); return; }

  const btn = $('#saveSettings');
  btn.textContent = 'SAVED.';
  setTimeout(() => { btn.textContent = 'SAVE SETTINGS'; }, 1500);
});

// --- Init ---
updatePomodoroUI();
loadStats();
loadSettings();
checkLockState();
