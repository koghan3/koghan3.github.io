const params  = new URLSearchParams(window.location.search);
const domain  = params.get('domain')  || 'unknown';
const minutes = params.get('minutes') || '30+';

document.getElementById('domainName').textContent = domain;
document.getElementById('timeSpent').textContent  = minutes;

document.getElementById('btnBlacklist').addEventListener('click', () => {
  chrome.runtime.sendMessage({ type: 'addToBlacklist', domain }, () => {
    document.getElementById('mainPanel').style.display = 'none';
    const panel = document.getElementById('confirmPanel');
    panel.classList.add('show');
    document.getElementById('confirmDomain').textContent = domain + ' has been added to the restricted list.';
    setTimeout(() => window.close(), 2500);
  });
});

document.getElementById('btnSkip').addEventListener('click', () => {
  window.close();
});
