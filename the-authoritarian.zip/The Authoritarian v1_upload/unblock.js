const params = new URLSearchParams(window.location.search);
const domain = params.get('domain') || 'unknown';
document.getElementById('domainName').textContent = domain;

const textarea    = document.getElementById('reasoning');
const wordCountEl = document.getElementById('wordCount');
const progressFill = document.getElementById('progressFill');
const submitBtn   = document.getElementById('btnSubmit');
const noPasteMsg  = document.getElementById('noPasteMsg');

const MIN_WORDS = 100;

// Disable paste and drop
textarea.addEventListener('paste', (e) => {
  e.preventDefault();
  noPasteMsg.style.display = 'block';
  setTimeout(() => { noPasteMsg.style.display = 'none'; }, 3000);
});
textarea.addEventListener('drop', (e) => e.preventDefault());

// Word counter
textarea.addEventListener('input', () => {
  const words = textarea.value.trim().split(/\s+/).filter(w => w.length > 0);
  const count  = words.length;
  const pct    = Math.min(100, (count / MIN_WORDS) * 100);

  wordCountEl.textContent    = `${count} / ${MIN_WORDS} words`;
  progressFill.style.width   = `${pct}%`;

  if (count >= MIN_WORDS) {
    wordCountEl.className = 'word-count done';
    progressFill.className = 'progress-fill done';
    submitBtn.disabled = false;
    submitBtn.classList.add('ready');
    submitBtn.textContent = 'PETITION — UNBLOCK ' + domain.toUpperCase();
  } else if (count >= Math.floor(MIN_WORDS / 2)) {
    wordCountEl.className = 'word-count mid';
    progressFill.className = 'progress-fill amber';
    submitBtn.disabled = true;
    submitBtn.classList.remove('ready');
    submitBtn.textContent = `${MIN_WORDS - count} MORE WORDS REQUIRED`;
  } else {
    wordCountEl.className = 'word-count low';
    progressFill.className = 'progress-fill';
    progressFill.style.background = '';
    submitBtn.disabled = true;
    submitBtn.classList.remove('ready');
    submitBtn.textContent = `${MIN_WORDS - count} MORE WORDS REQUIRED`;
  }
});

// Submit
submitBtn.addEventListener('click', () => {
  const words = textarea.value.trim().split(/\s+/).filter(w => w.length > 0);
  if (words.length < MIN_WORDS) return;

  chrome.runtime.sendMessage({ type: 'removeFromBlacklist', domain }, (resp) => {
    if (resp && resp.error === 'locked') {
      alert('Settings are locked. Unlock before petitioning for removal.');
      return;
    }
    document.getElementById('mainForm').style.display = 'none';
    const panel = document.getElementById('confirmPanel');
    panel.classList.add('show');
    document.getElementById('confirmMsg').textContent = domain + ' has been removed from the restricted list.';
    setTimeout(() => window.close(), 2500);
  });
});

document.getElementById('btnCancel').addEventListener('click', () => window.close());
