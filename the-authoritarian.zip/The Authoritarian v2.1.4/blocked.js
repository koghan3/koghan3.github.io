const params      = new URLSearchParams(window.location.search);
const domain      = params.get('domain')      || 'this site';
const reason      = params.get('reason')      || 'daily';
const cooldownEnd = parseInt(params.get('cooldownEnd') || '0');

// Doc number
document.getElementById('docNumber').textContent = 'DOC-' + String(Math.floor(Math.random() * 999999)).padStart(6, '0');

document.getElementById('domainName').textContent = domain;

const reasons = {
  pomodoro: {
    label: 'CLASSIFICATION: FOCUS SESSION ACTIVE',
    text:  'Access to this domain is suspended during an active work session. The Ministry requires your full attention. Your break is forthcoming.'
  },
  daily: {
    label: 'CLASSIFICATION: DAILY QUOTA EXCEEDED',
    text:  'Your daily allowance for this domain has been exhausted. Return tomorrow or apply for an allocation increase through Settings.'
  },
  visit: {
    label: 'CLASSIFICATION: VISIT DURATION EXCEEDED',
    text:  'You have exceeded the permitted duration for a single visit. Stand down and return when your cooldown period has elapsed.'
  },
  cooldown: {
    label: 'CLASSIFICATION: COOLDOWN IN EFFECT',
    text:  'Per-visit limit was reached. Access is suspended for the cooldown period. Use this time productively.'
  }
};

const r = reasons[reason] || reasons.daily;
document.getElementById('reasonLabel').textContent = r.label;
document.getElementById('reasonText').textContent  = r.text;

// Stamp label
if (reason === 'daily') {
  document.getElementById('stampEl').textContent = 'DENIED';
} else if (reason === 'pomodoro') {
  document.getElementById('stampEl').textContent = 'BLOCKED';
}

// Cooldown timer
if ((reason === 'cooldown' || reason === 'visit') && cooldownEnd > Date.now()) {
  const box     = document.getElementById('cooldownBox');
  const timerEl = document.getElementById('cooldownTimer');
  box.style.display = 'block';

  function updateTimer() {
    const remaining = cooldownEnd - Date.now();
    if (remaining <= 0) {
      timerEl.textContent = '00:00';
      clearInterval(interval);
      return;
    }
    const m = Math.floor(remaining / 60000);
    const s = Math.floor((remaining % 60000) / 1000);
    timerEl.textContent = `${String(m).padStart(2, '0')}:${String(s).padStart(2, '0')}`;
  }
  updateTimer();
  const interval = setInterval(updateTimer, 1000);
}

// Quotes
const quotes = [
  'Wasting time is the greatest sin a human being can commit against himself.',
  'Work, work, and work. This is the only path to honor and dignity.',
  'A person who has a goal and works toward it every day is never defeated.',
  'Laziness is the enemy of progress. It must be combated with discipline.',
  'Knowledge without action is like a tree without fruit.',
  'Do not let a single hour pass without having done something worthy of it.',
  'The pen and the mind must never rest; through them nations rise.',
  'Idleness corrupts the soul. Occupy yourself with what is beneficial.',
  'Self-discipline is the foundation upon which all achievement is built.',
  'Every great thing begins with the decision to focus and not waver.'
];
const q = quotes[Math.floor(Math.random() * quotes.length)];
document.getElementById('quoteText').textContent   = '"' + q + '"';
document.getElementById('quoteAuthor').textContent = '';

document.getElementById('btnBack').addEventListener('click', () => history.back());
