// ==========================================
// The Authoritarian — Distraction Detected
// ==========================================

const params    = new URLSearchParams(window.location.search);
const remaining = parseInt(params.get('remaining') || '0');
const session   = parseInt(params.get('session')   || '1');

// Display session number
document.getElementById('sessionNum').textContent = session;

// Display remaining time at interruption
function fmtTime(ms) {
  if (ms <= 0) return '0:00';
  const totalSec = Math.ceil(ms / 1000);
  const m = Math.floor(totalSec / 60);
  const s = totalSec % 60;
  return `${m}:${String(s).padStart(2, '0')}`;
}
document.getElementById('remainingDisplay').textContent = fmtTime(remaining);

// ---- Work for 5 more minutes button ----
// Resumes the paused session with remaining time + 5 min bonus
document.getElementById('btnWorkFive').addEventListener('click', () => {
  const btn = document.getElementById('btnWorkFive');
  btn.disabled    = true;
  btn.textContent = 'Starting…';

  chrome.runtime.sendMessage({ type: 'continueAfterDistraction' }, (resp) => {
    if (chrome.runtime.lastError || !resp || !resp.success) {
      btn.disabled    = false;
      btn.textContent = 'Work for 5 more minutes';
      return;
    }
    window.close();
  });
});

// ---- End session button ----
document.getElementById('btnEnd').addEventListener('click', () => {
  const btn = document.getElementById('btnEnd');
  btn.disabled   = true;
  btn.textContent = 'Ending…';

  chrome.runtime.sendMessage({ type: 'endSessionAfterDistraction' }, () => {
    window.close();
  });
});
