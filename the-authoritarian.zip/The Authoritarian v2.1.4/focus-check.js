const params  = new URLSearchParams(window.location.search);
const session = params.get('session') || '1';
document.getElementById('sessionTag').textContent = 'SESSION ' + session;

function show(id) {
  document.querySelectorAll('.panel').forEach(p => p.classList.remove('show'));
  document.getElementById(id).classList.add('show');
}

function msg(type) {
  return new Promise(resolve => chrome.runtime.sendMessage({ type }, resolve));
}

// Confirmed on task
document.getElementById('btnYes').addEventListener('click', async () => {
  await msg('focusCheckAnswered');
  show('panelFocused');
  window.close();
  setTimeout(() => window.close(), 500);
});

// Distracted — pause the session timer immediately
document.getElementById('btnNo').addEventListener('click', async () => {
  await msg('pauseSessionForDistraction');
  show('panelDistracted');
});

// Keep working: resume paused session with +5 min added
document.getElementById('btnKeepWorking').addEventListener('click', async () => {
  const btn = document.getElementById('btnKeepWorking');
  btn.disabled = true;
  await msg('continueAfterDistraction');
  show('panelExtended');
  setTimeout(() => window.close(), 1500);
});

// Restart session
document.getElementById('btnRestart').addEventListener('click', async () => {
  show('panelRestarted');
  await msg('restartSession');
  setTimeout(() => window.close(), 1500);
});

// End working
document.getElementById('btnEnd').addEventListener('click', async () => {
  show('panelEnded');
  await msg('stopPomodoro');
  setTimeout(() => window.close(), 1500);
});
