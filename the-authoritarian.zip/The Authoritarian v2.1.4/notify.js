const params    = new URLSearchParams(window.location.search);
const title     = params.get('title')   || 'DISPATCH';
const msg       = params.get('msg')     || '';
const endTime   = parseInt(params.get('endTime') || '0', 10);
const mode      = params.get('mode')    || 'work';  // 'work' | 'break' | 'longbreak'
const CLOSE_AFTER = 20; // seconds before auto-close

document.getElementById('dispatchTitle').textContent = title;
document.getElementById('dispatchMsg').textContent   = msg;

// Set eyebrow label based on session mode
const eyebrowLabels = {
  work:      'FOCUS SESSION STARTED',
  break:     'BREAK TIME',
  longbreak: 'LONG BREAK TIME'
};
document.getElementById('dispatchEyebrow').textContent = eyebrowLabels[mode] || 'SESSION UPDATE';

// Session timer
const timerEl   = document.getElementById('sessionTimer');
const timerSec  = document.getElementById('timerSection');

function fmt(ms) {
  if (ms <= 0) return '00:00';
  const s = Math.ceil(ms / 1000);
  const m = Math.floor(s / 60);
  return `${String(m).padStart(2,'0')}:${String(s % 60).padStart(2,'0')}`;
}

if (endTime) {
  timerEl.classList.add(mode === 'work' ? 'work' : 'break');
  const tick = () => { timerEl.textContent = fmt(endTime - Date.now()); };
  tick();
  setInterval(tick, 1000);
} else {
  // No session timer — hide the section
  timerSec.style.display = 'none';
  timerEl.style.display  = 'none';
}

// Auto-dismiss countdown
const fillEl   = document.getElementById('dismissFill');
const footerEl = document.getElementById('dismissFooter');
const start    = Date.now();

const countdown = setInterval(() => {
  const elapsed  = (Date.now() - start) / 1000;
  const left     = Math.max(0, CLOSE_AFTER - elapsed);
  const pct      = (left / CLOSE_AFTER) * 100;
  fillEl.style.width = `${pct}%`;
  footerEl.textContent = `Closing in ${Math.ceil(left)} second${Math.ceil(left) !== 1 ? 's' : ''}...`;
  if (left <= 0) { clearInterval(countdown); window.close(); }
}, 200);

document.getElementById('dismissBtn').addEventListener('click', () => {
  clearInterval(countdown);
  window.close();
});
