// ==========================================
// The Authoritarian — Welcome / Consent page
// ==========================================

const consentCheck = document.getElementById('consentCheck');
const btnProceed   = document.getElementById('btnProceed');

consentCheck.addEventListener('change', () => {
  if (consentCheck.checked) {
    btnProceed.disabled = false;
    btnProceed.classList.add('ready');
    btnProceed.textContent = 'GOT IT — CONTINUE';
  } else {
    btnProceed.disabled = true;
    btnProceed.classList.remove('ready');
    btnProceed.textContent = 'Tick the box above to continue';
  }
});

btnProceed.addEventListener('click', () => {
  if (!consentCheck.checked) return;
  // Mark consent given so this page is not shown again
  chrome.storage.local.set({ consentGiven: true }, () => {
    window.close();
  });
});
